
DawnModJS.RunName.add("星空测试")
DawnModJS.DawnRun.add(run(() => {
Events.on(EventType.ClientLoadEvent, cons(e => {
DawnEMC.魔晶设置量(星燃,40000)
DawnEMC.魔晶设置量(流光,100)
}))

var 星燃 = extend(DawnItemType,"星燃", Color.valueOf("ff0000ff"),{})
星燃.localizedName = "星燃";
星燃.SPType = new DawnSPType(6);
星燃.description = "星空中的可燃物";
星燃.details = "这东西看起来像已经在燃烧了";
星燃.frameTime = 1//每张贴图的帧数
星燃.frames = 1;//贴图数
星燃.transitionFrames = 1;//两张贴图之间的过渡帧*/
星燃.flammability = 5.50;//燃烧性
星燃.hardness = 0;//挖掘等级
星燃.explosiveness = 0;//爆炸性
星燃.radioactivity = 2.75;//辐射性
星燃.charge = 0;//放电性
星燃.cost = 1;
//星燃.lowPriority = true;

var 流光 = extend(DawnLiquidType,"流光",Color.valueOf("ffff00ff"),{})
流光.localizedName = "流光";
流光.SPType = new DawnSPType(7);
流光.description = "星空中闪烁光芒的液体";
流光.details = "像液体般流动，闪烁着光芒的星空光液体";
流光.explosiveness = 0;
流光.flammability = 0;
流光.temperature = -1;
流光.heatCapacity = 5;
流光.viscosity = 0.5;

var 纯粹 = extend(DawnStatusEffect,"纯粹",{})
纯粹.localizedName = "纯粹";
纯粹.description = "由流光所呈现出来的状态";
纯粹.details = "完全无杂质的状态，纯粹";
纯粹.SPType = new DawnSPType(7);
纯粹.damageMultiplier = 5;
纯粹.healthMultiplier = 10;
纯粹.speedMultiplier = 4;
纯粹.reloadMultiplier = 2.5;
纯粹.permanent = true;
纯粹.damage = -10;

var 光裂 = extend(DawnStatusEffect,"光裂",{})
光裂.localizedName="光裂"
光裂.description = "光亮毁裂时的状态"
光裂.details = "连光都无法逃离的状态"
光裂.SPType = new DawnSPType(7)
光裂.damageMultiplier = 0.1
光裂.healthMultiplier = 0.01
光裂.speedMultiplier = 0.3
光裂.reloadMultiplier = 0.5
光裂.permanent = true//一直存在
光裂.damage = 100

var 星燃转化厂 = extend(MultiCrafter,"星燃转化厂",1,{})
星燃转化厂.SPType = new DawnSPType(星燃转化厂,5).方块血量(5800).装甲("星辉装甲",4000,10000).建造时间(5)
星燃转化厂.localizedName = "星燃转化厂"
星燃转化厂.description = "将铜重构为星燃"
星燃转化厂.details = "运用星尘工艺(一种重构工艺)，将铜打碎，并在不稳定态时重铸为星燃"
星燃转化厂.buildVisibility = BuildVisibility.shown
星燃转化厂.category = Category.crafting
星燃转化厂.requirements = ItemStack.with(
    Items.copper, 2000,
    Items.titanium,1500,
    Items.silicon,750,
    Items.metaglass,375
)
星燃转化厂.addRecipe(
	new Recipe.InputContents(ItemStack.with(Items.copper, 15)),
	new Recipe.OutputContents(ItemStack.with(星燃, 3)), 60.0, true
)
星燃转化厂.size = 2
星燃转化厂.dumpToggle = false;//需不需要选择配方 如为false 则不需要选择配方 全配方同时工作
星燃转化厂.itemCapacity = 50
const 星燃生产 = new ParticleEffect()
星燃生产.lifetime = 30
星燃生产.sizeFrom = 3
星燃生产.sizeTo = 0
星燃生产.colorFrom = Color.valueOf("ff0000ff")
星燃生产.colorTo = Color.valueOf("ff000000")
星燃生产.particles = 4
星燃转化厂.craftEffect = 星燃生产

var 流光提取器 = extend(MultiCrafter,"流光提取器",1,{})
流光提取器.SPType = new DawnSPType(流光提取器,6).方块血量(8400).装甲("尘云甲",10000,20000).建造时间(7.5)
流光提取器.localizedName = "流光提取器"
流光提取器.description = "从铜中提取出流光"
流光提取器.details = "通过极光(一种提取技术)，将铜在纯粹状态下液化，之后蒸发再度液化成为流光"
流光提取器.buildVisibility = BuildVisibility.shown
流光提取器.category = Category.crafting
流光提取器.requirements = ItemStack.with(
    Items.copper,1500,
    Items.titanium,3750,
    Items.silicon,420,
    Items.metaglass,1500
)
流光提取器.addRecipe(
	new Recipe.InputContents(ItemStack.with(Items.copper, 15),LiquidStack.with(Liquids.water,1.2)),
	new Recipe.OutputContents(LiquidStack.with(流光, 0.8)), 60.0, true
)
流光提取器.size = 2
流光提取器.dumpToggle = false
流光提取器.itemCapacity = 70
流光提取器.liquidCapacity = 500
const 流光生产1 = new WaveEffect()
流光生产1.lifetime = 60
流光生产1.sizeFrom = 7
流光生产1.sizeTo = 0
流光生产1.colorFrom = Color.valueOf("ffff00ff")
流光生产1.colorTo = Color.valueOf("7f7f00ff")
/*const 流光生产2 = new Effect(30, cons(e => {
Draw.rect(Core.atlas.find("流光提取器tx"), e.x, e.y)
}))*/
流光提取器.craftEffect = MultiEffect(流光生产1)
/*new Effect(60, cons(e => {
    Draw.color(Color.valueOf("f500ff"));
    for (let i = 0; i < 4; i++) {
        Drawf.tri(e.x, e.y, 4 * e.fin(), 4 * 3, 90 * i)
    };
    Lines.circle(e.x, e.y, 4 * e.fin() * 10);
}));*/
const 流光持续 = new WaveEffect()
流光持续.lifetime = 30
流光持续.sizeFrom = 0
流光持续.sizeTo = 2
流光持续.colorFrom = Color.valueOf("ffff00ff")
流光持续.colorTo = Color.valueOf("7f7f00ff")
流光提取器.updateEffect = 流光持续
流光提取器.updateEffectChance = 0.03



/*
var 赛博液体 = extend(AnimatedLiquid, "赛博液体", Color.valueOf("000000"), {});
赛博液体.SPType = new DawnSPType(7);

赛博液体.frameTime = 2;//每张贴图的帧数
赛博液体.frames = 14;//贴图数
赛博液体.transitionFrames = 3;//两张贴图之间的过渡帧

const 荷子 = CoreDawn.DawnProject(ContentType.item, "荷子")

const AAA = new DawnEnergyFieldAbility(40.0, 65.0, 180.0)
AAA.statusDuration = 360.0;
AAA.maxTargets = 25;

var 测试工厂 = extend(MultiCrafter, "测试工厂", 2, {});//2为两个配方
测试工厂.SPType = new DawnSPType(测试工厂, 2).能力(AAA)
测试工厂.buildVisibility = BuildVisibility.shown;
测试工厂.category = Category.logic;
测试工厂.requirements = ItemStack.with(
	Items.copper, 1
);
测试工厂.addRecipe(
	new Recipe.InputContents(ItemStack.with(荷子, 2), 5),
	new Recipe.OutputContents(ItemStack.with(测试物品, 2)), 60.0, true
)
测试工厂.addRecipe(
	new Recipe.InputContents(ItemStack.with(测试物品, 2), 5),
	new Recipe.OutputContents(ItemStack.with(荷子, 2)), 60.0, true
)
测试工厂.size = 2;
测试工厂.itemCapacity = 100;
测试工厂.craftEffect = Fx.pulverizeMedium;
测试工厂.updateEffect = Fx.none;
测试工厂.dumpToggle = true;//需不需要选择配方 如为false 则不需要选择配方 全配方同时工作

var 测试可建造地板 = extend(BuildFloorBlock, "测试可建造地板", {});
测试可建造地板.buildVisibility = BuildVisibility.shown;
测试可建造地板.category = Category.logic;
测试可建造地板.SPType = new DawnSPType(测试可建造地板, 1);
测试可建造地板.size = 5;
测试可建造地板.floor = Blocks.darkPanel2
测试可建造地板.overlay = Blocks.oreTitanium
*/
}))